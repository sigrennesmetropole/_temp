module.exports = {
    name: "RTGEExtension"
};
